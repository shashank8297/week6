package org.infnite.interfaces;

import java.util.List;

import org.infnite.pojo.Cart;

public interface CartInterface {
	public void insert(String pname, int amt, int qty, int total);
	
	public void update();
	
	public void delete();
	
	public List<Cart> display();
}

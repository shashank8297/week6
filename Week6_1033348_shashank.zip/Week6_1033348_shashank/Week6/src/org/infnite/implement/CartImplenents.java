package org.infnite.implement;

import java.util.List;



import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import org.infnite.daohelper.DAOHelper;
import org.infnite.interfaces.CartInterface;
import org.infnite.pojo.Cart;

public class CartImplenents implements CartInterface {

	
	Session sessionObj;
	static SessionFactory sessionFactoryObj;
	Transaction tx = null;
	
	@Override
	public void update() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void delete() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<Cart> display() {
		// TODO Auto-generated method stub
		List<Cart> ls = null;
		String msg = null;
		try {
			sessionObj = DAOHelper.buildSessionFactory().openSession();
			tx = sessionObj.beginTransaction();
			Query q = sessionObj.createQuery("from student");
			ls = q.list();
			for (Cart s : ls) {
				msg = s.getId() + " " + s.getName() + " " + s.getAmount() + " " + s.getQuantity()+" "+s.getTotalprice();
			}
			tx.commit();
		} catch (HibernateException e) {
			e.printStackTrace();
		} finally {
			// Close hibernate session.
			//sessionObj.close();
		}
		return ls;
	}

	@Override
	public void insert(String pname, int amt, int qty, int total) {
		// TODO Auto-generated method stub
		int x = 0;
		try {
			sessionObj = DAOHelper.buildSessionFactory().openSession();
			sessionObj.beginTransaction();
			Cart c = new Cart();
			c.setName(pname);
			c.setAmount(amt);
			c.setQuantity(qty);
			c.setTotalprice(total);
			sessionObj.save(c);
			sessionObj.getTransaction().commit();
		} catch (HibernateException e) {

 

			e.printStackTrace();
		} finally {
			// Close hibernate session.
			//sessionObj.close();
		}
	}
}

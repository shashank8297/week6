package org.infnite.test;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.infnite.implement.CartImplenents;
import org.infnite.pojo.Cart;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class Display {
	@RequestMapping(value="/display", method=RequestMethod.POST)
	public String display(HttpServletRequest request, HttpServletResponse response ,Model m){
		System.out.println("Dispaly");
		List<Cart> ls = null;
		String msg = null;
		CartImplenents sd = new CartImplenents();
		ls=sd.display();
		m.addAttribute("msg",ls);
		return "display";
		//return null;
	}
}

package org.infnite.test;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.infnite.implement.CartImplenents;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class Insert {

	@RequestMapping(value="/insert", method=RequestMethod.POST)
	public String insertdata(HttpServletRequest request, HttpServletResponse response){
		System.out.println("Insert");
		
		return "insert";
	}
	@RequestMapping("/insertdata")
	public String insert(HttpServletRequest request, HttpServletResponse response){
		System.out.println("Insert data");
		String pname= request.getParameter("product_name"); //getParameter("pname");
		int amt = Integer.parseInt(request.getParameter("amount"));
		int qty = Integer.parseInt(request.getParameter("quantity"));
		int tp = amt*qty;
		CartImplenents impl = new CartImplenents();
		impl.insert(pname, amt, qty, tp);
		/*if(y != 0){
			return "success";
		}
		else{
			return "fail";
		}*/
		return "success";
	}
}
